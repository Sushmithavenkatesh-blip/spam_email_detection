# Spam Email Detection

Frontend-only ML app. React + Vite + Tailwind + from-scratch TF-IDF/Naive Bayes/Logistic Regression +
Recharts + PapaParse + jsPDF + html2canvas. No backend, no external APIs. Text cleaning, vocabulary
building, TF-IDF vectorization, training, evaluation, prediction, and PDF report all run in the browser
— nothing you paste into the detector is sent anywhere or stored.

Both models are lightweight and TF-IDF-based, so no TensorFlow.js bundle is pulled in: Naive Bayes is
inherently from-scratch, and Logistic Regression trains by plain full-batch gradient descent (150 epochs
converges in well under a second even in the browser, since the vocabulary is capped at a few thousand
terms).

## Run it

npm install
npm run dev

Open the printed local URL. First load: dataset loads, email text is cleaned and tokenized, a vocabulary
is built from the training split, TF-IDF features are computed, then both models train before the
dashboard is ready.

## Structure

- public/data/spam_emails.csv — 1,510 synthetic emails (~38% spam) built from template fragments, with
  a handful of duplicate and empty rows to exercise cleaning
- src/ml/preprocessing.js — text cleaning (HTML/URL stripping, lowercasing, punctuation removal — no
  stopword removal, so spam-indicative words are never blindly discarded) + tokenization + train/test
  split
- src/ml/tfidf.js — vocabulary building (capped at 3,000 terms, min document frequency 2) and TF-IDF
  vectorization, fit on the training split only
- src/ml/naiveBayes.js — Multinomial Naive Bayes over the TF-IDF-weighted features (Laplace smoothing)
- src/ml/logisticRegression.js — from-scratch gradient descent with L2 regularization
- src/utils/metrics.js — accuracy, precision, recall, F1, confusion matrix, ROC-AUC (rank-sum formula)
- src/utils/vocabulary.js — word frequency by class, and model-derived spam/legitimate-associated terms
- src/utils/textAnalysis.js — per-message stats (char/word/sentence/URL/number/uppercase/special-char
  counts) computed on the raw, uncleaned text
- src/pages/ — Dashboard, Spam Detector, Email Analysis, Model Performance
- src/components/ — Sidebar, Header, StatCard, ChartCard, EmailInput, PredictionResult, EmailTable,
  EmailDetails, ConfusionMatrix, ModelMetrics, VocabularyChart, ReportButton
- src/utils/reportGenerator.js — builds the downloadable PDF (jsPDF + html2canvas)

Swap in your own data by replacing public/data/spam_emails.csv, keeping the same column names (label,
message). Labels are normalized internally — spam/1/true → spam, ham/legitimate/0/false → ham.

## Detector

On the Spam Detector page, pick a model, paste email text, and click Detect Spam. The result shows spam
probability, a text-statistics breakdown, and any vocabulary terms the model associates with spam or
legitimate mail in this dataset — shown as analysis, never as a standalone rule; the classification
itself always comes from the trained model, and is always framed as a model prediction, not a guarantee.

## Report download

"Download Report" generates spam_email_detection_report.pdf with the dataset summary, both models'
metrics, confusion matrix, current email prediction (word/char counts and probability only — no raw
message text is embedded), dynamic insights, and a chart image. Blocks with the spec'd messages if the
dataset/model aren't ready or no email text was entered.
