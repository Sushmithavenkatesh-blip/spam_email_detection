/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1B2130',
        slate: { 925: '#131826' },
        clay2: '#B8543F',
        teal4: '#2C7C7A',
        indigo4: '#4A5FB0',
        paper: '#F6F7F8',
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
