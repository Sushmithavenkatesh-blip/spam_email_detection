const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

/** Generates dynamic, dataset-derived observations — never hardcoded claims. */
export function generateDatasetInsights(emails, summary, vocabModel) {
  const insights = []

  insights.push(`Spam emails represent ${summary.spamPercentage.toFixed(1)}% of the dataset.`)

  const spamLengths = emails.filter((e) => e.label === 'spam').map((e) => e.message.length)
  const hamLengths = emails.filter((e) => e.label === 'ham').map((e) => e.message.length)
  if (spamLengths.length && hamLengths.length) {
    const spamAvg = avg(spamLengths)
    const hamAvg = avg(hamLengths)
    const comparison = spamAvg > hamAvg ? 'longer' : 'shorter'
    insights.push(`Spam messages are ${comparison} on average than legitimate messages in this dataset (${spamAvg.toFixed(0)} vs ${hamAvg.toFixed(0)} characters).`)
  }

  if (vocabModel) {
    insights.push(`The current vocabulary contains ${vocabModel.vocabulary.length} terms (${vocabModel.rareTermsRemoved} rare terms removed).`)
  }

  return insights
}

/** Adds a model-comparison insight once both models have been trained. */
export function generateModelInsight(models) {
  const entries = Object.values(models)
  if (entries.length < 2) return null
  const best = [...entries].sort((a, b) => b.metrics.f1 - a.metrics.f1)[0]
  return `The selected model achieved an F1 score of ${(best.metrics.f1 * 100).toFixed(1)}% using ${best.label}.`
}
