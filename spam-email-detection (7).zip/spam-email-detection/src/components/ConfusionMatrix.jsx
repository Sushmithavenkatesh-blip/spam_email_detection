import React from 'react'

export default function ConfusionMatrix({ matrix }) {
  const { tp, tn, fp, fn } = matrix
  return (
    <div className="bg-white rounded-lg border border-black/5 p-5 min-w-0">
      <h3 className="text-sm font-medium text-ink mb-4">Confusion Matrix</h3>
      <div className="grid grid-cols-[auto_1fr_1fr] gap-1 text-sm max-w-sm">
        <div />
        <div className="text-center text-xs text-ink/40 pb-1">Predicted Spam</div>
        <div className="text-center text-xs text-ink/40 pb-1">Predicted Legit.</div>

        <div className="text-xs text-ink/40 flex items-center pr-2">Actual Spam</div>
        <div className="bg-teal4/10 text-teal4 rounded p-3 text-center font-medium">{tp}</div>
        <div className="bg-clay2/10 text-clay2 rounded p-3 text-center font-medium">{fn}</div>

        <div className="text-xs text-ink/40 flex items-center pr-2">Actual Legit.</div>
        <div className="bg-clay2/10 text-clay2 rounded p-3 text-center font-medium">{fp}</div>
        <div className="bg-teal4/10 text-teal4 rounded p-3 text-center font-medium">{tn}</div>
      </div>
    </div>
  )
}
