import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import ChartCard from './ChartCard'

export default function VocabularyChart({ terms, dataKey, title, description, color, innerRef }) {
  return (
    <ChartCard innerRef={innerRef} title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={terms} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
          <CartesianGrid stroke="#e9eaec" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 11 }} />
          <YAxis type="category" dataKey="term" tick={{ fontSize: 10 }} width={90} />
          <Tooltip />
          <Bar dataKey={dataKey} fill={color} radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
