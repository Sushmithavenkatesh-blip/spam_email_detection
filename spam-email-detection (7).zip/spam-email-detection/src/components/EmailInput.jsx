import React, { useState } from 'react'

export default function EmailInput({ modelKey, onModelChange, onSubmit, disabled, error }) {
  const [text, setText] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(text)
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-black/5 p-6 space-y-4">
      <div>
        <label className="text-sm text-ink/70 block mb-1">Model</label>
        <select
          value={modelKey}
          onChange={(e) => onModelChange(e.target.value)}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="naive-bayes">Naive Bayes</option>
          <option value="logistic-regression">Logistic Regression</option>
        </select>
      </div>

      <div>
        <label className="text-sm text-ink/70 block mb-1">Email Content</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste your email content here…"
          rows={12}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm resize-y min-w-0"
        />
      </div>

      {error && <p className="text-xs text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={disabled}
        className="w-full bg-ink text-white rounded-md py-2.5 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink/90 transition-colors"
      >
        {disabled ? 'Training model…' : 'Detect Spam'}
      </button>

      <p className="text-xs text-ink/40">
        Processed entirely in your browser. Nothing you paste here is sent anywhere or stored. This is a
        model-based classification, not a guarantee — always use your own judgment alongside it.
      </p>
    </form>
  )
}
