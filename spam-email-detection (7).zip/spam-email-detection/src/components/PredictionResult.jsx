import React from 'react'

export default function PredictionResult({ result, innerRef }) {
  if (!result) {
    return (
      <div className="h-full min-h-[240px] bg-white rounded-lg border border-black/5 border-dashed flex items-center justify-center text-ink/40 text-sm p-6 text-center">
        Paste an email and click Detect Spam to see a result here.
      </div>
    )
  }

  const { predictedLabel, spamProbability, modelLabel, textStats, matchedTerms } = result
  const isSpam = predictedLabel === 'spam'
  const pct = (spamProbability * 100).toFixed(0)

  return (
    <div ref={innerRef} className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Classification</p>
      <p className={`font-display text-3xl mb-1 ${isSpam ? 'text-clay2' : 'text-teal4'}`}>
        {isSpam ? 'Spam' : 'Legitimate'}
      </p>
      <p className="text-xs text-ink/40 mb-5">Model-based classification from {modelLabel} — not a guaranteed outcome.</p>

      <div className="mb-2 flex justify-between text-sm">
        <span className="text-ink/60">Spam Probability</span>
        <span className="text-ink font-medium">{pct}%</span>
      </div>
      <div className="w-full h-2.5 bg-black/5 rounded-full overflow-hidden mb-6">
        <div
          className={`h-full rounded-full transition-all duration-500 ${isSpam ? 'bg-clay2' : 'bg-teal4'}`}
          style={{ width: `${pct}%` }}
        />
      </div>

      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Text Analysis</p>
      <div className="grid grid-cols-3 gap-2 mb-5 text-xs">
        {[
          ['Characters', textStats.charCount],
          ['Words', textStats.wordCount],
          ['URLs', textStats.urlCount],
          ['Numbers', textStats.numberCount],
          ['Uppercase', textStats.uppercaseCount],
          ['Special Chars', textStats.specialCharCount],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper rounded px-2 py-2">
            <p className="text-ink/40">{label}</p>
            <p className="text-ink font-medium">{value}</p>
          </div>
        ))}
      </div>

      {matchedTerms?.length > 0 && (
        <div className="bg-paper rounded-md p-4">
          <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Important Terms Detected</p>
          <div className="flex flex-wrap gap-1.5 mb-2">
            {matchedTerms.map((t) => (
              <span key={t} className="text-xs px-2 py-1 rounded-full bg-black/5 text-ink/70">{t}</span>
            ))}
          </div>
          <p className="text-xs text-ink/50">
            These terms had model influence for this dataset — they're shown as analysis, not used as a
            standalone rule. The classification above always comes from the trained model.
          </p>
        </div>
      )}
    </div>
  )
}
