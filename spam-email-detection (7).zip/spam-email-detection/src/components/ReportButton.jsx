import React, { useState } from 'react'
import { generateSpamReportPdf } from '../utils/reportGenerator'

export default function ReportButton({ summary, trainingResult, modelKey, prediction, insights, chartElement }) {
  const [status, setStatus] = useState('idle')
  const [error, setError] = useState(null)

  const handleClick = async () => {
    setError(null)
    if (!summary) {
      setError('Please load the email dataset first.')
      return
    }
    if (!trainingResult) {
      setError('Please train the model first.')
      return
    }
    setStatus('generating')
    try {
      await generateSpamReportPdf({ summary, trainingResult, modelKey, prediction, insights, chartElement })
      setStatus('idle')
    } catch (err) {
      setError('Unable to generate report. Please try again.')
      setStatus('error')
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={status === 'generating'}
        className="text-sm px-4 py-2.5 rounded-md bg-ink text-white hover:bg-ink/90 transition-colors disabled:opacity-50"
      >
        {status === 'generating' ? 'Generating PDF…' : 'Download Report'}
      </button>
      {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
    </div>
  )
}
