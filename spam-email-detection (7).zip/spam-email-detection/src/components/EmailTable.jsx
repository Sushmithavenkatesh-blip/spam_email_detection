import React, { useMemo, useState } from 'react'

const PAGE_SIZE = 10

export default function EmailTable({ emails, onSelect, selectedId }) {
  const [search, setSearch] = useState('')
  const [labelFilter, setLabelFilter] = useState('all')
  const [sortKey, setSortKey] = useState('wordCount')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    let result = emails
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      result = result.filter((e) => e.message.toLowerCase().includes(q))
    }
    if (labelFilter !== 'all') result = result.filter((e) => e.label === labelFilter)

    return [...result].sort((a, b) => {
      const diff = a[sortKey] - b[sortKey]
      return sortDir === 'asc' ? diff : -diff
    })
  }, [emails, search, labelFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else { setSortKey(key); setSortDir('desc') }
    setPage(1)
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 p-5 min-w-0">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <input
          type="text"
          placeholder="Search email text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          className="flex-1 border border-black/10 rounded-md px-3 py-2 text-sm min-w-0"
        />
        <select value={labelFilter} onChange={(e) => { setLabelFilter(e.target.value); setPage(1) }} className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Labels</option>
          <option value="spam">Spam</option>
          <option value="ham">Legitimate</option>
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[620px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              <th className="py-2 pr-4">ID</th>
              <th className="py-2 pr-4">Label</th>
              <th onClick={() => toggleSort('wordCount')} className="py-2 pr-4 cursor-pointer select-none">
                Word Count{sortKey === 'wordCount' ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
              </th>
              <th onClick={() => toggleSort('charCount')} className="py-2 pr-4 cursor-pointer select-none">
                Char Count{sortKey === 'charCount' ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
              </th>
              <th className="py-2 pr-4">URLs</th>
              <th className="py-2 pr-4">Preview</th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((e) => (
              <tr
                key={e.id}
                onClick={() => onSelect(e)}
                className={`border-b border-black/5 last:border-0 cursor-pointer hover:bg-black/[0.02] ${selectedId === e.id ? 'bg-black/[0.03]' : ''}`}
              >
                <td className="py-2 pr-4">#{e.id}</td>
                <td className="py-2 pr-4">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${e.label === 'spam' ? 'bg-clay2/10 text-clay2' : 'bg-teal4/10 text-teal4'}`}>
                    {e.label === 'spam' ? 'Spam' : 'Legitimate'}
                  </span>
                </td>
                <td className="py-2 pr-4">{e.wordCount}</td>
                <td className="py-2 pr-4">{e.charCount}</td>
                <td className="py-2 pr-4">{e.urlCount}</td>
                <td className="py-2 pr-4 max-w-xs truncate">{e.message}</td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr><td colSpan={6} className="py-6 text-center text-ink/40">No emails match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4 text-sm text-ink/50">
        <span>{filtered.length} emails</span>
        <div className="flex items-center gap-2">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={currentPage <= 1} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Prev</button>
          <span>{currentPage} / {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Next</button>
        </div>
      </div>
    </div>
  )
}
