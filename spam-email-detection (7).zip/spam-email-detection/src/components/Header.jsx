import React from 'react'

const TITLES = {
  dashboard: ['Dashboard', 'Dataset overview and spam patterns'],
  detector: ['Spam Detector', 'Paste an email to classify it'],
  analysis: ['Email Analysis', 'Text characteristics and word patterns'],
  performance: ['Model Performance', 'Test-set metrics for both classifiers'],
}

export default function Header({ activePage, onMenuClick, status, model }) {
  const [title, subtitle] = TITLES[activePage] || ['', '']
  return (
    <header className="sticky top-0 z-10 bg-paper/95 backdrop-blur border-b border-black/5 px-4 md:px-8 py-4 flex items-center justify-between min-w-0">
      <div className="flex items-center gap-3 min-w-0">
        <button className="md:hidden p-2 -ml-2 rounded hover:bg-black/5 flex-shrink-0" onClick={onMenuClick} aria-label="Open navigation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M3 12h18M3 18h18" />
          </svg>
        </button>
        <div className="min-w-0">
          <h1 className="font-display text-xl md:text-2xl text-ink truncate">{title}</h1>
          <p className="text-sm text-ink/50 truncate">{subtitle}</p>
        </div>
      </div>
      <div className="hidden sm:flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-white border border-black/5 flex-shrink-0">
        <span className="text-ink/50">{model}</span>
        <span className="w-px h-3 bg-black/10" />
        <span
          className={`w-2 h-2 rounded-full ${
            status === 'ready' ? 'bg-teal4' : status === 'error' ? 'bg-red-500' : 'bg-clay2 animate-pulse'
          }`}
        />
        <span className="text-ink/60">
          {status === 'ready' ? 'Model trained' : status === 'error' ? 'Error' : 'Training…'}
        </span>
      </div>
    </header>
  )
}
