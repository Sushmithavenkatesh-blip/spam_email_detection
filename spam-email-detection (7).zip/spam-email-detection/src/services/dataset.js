import Papa from 'papaparse'

const SPAM_LABELS = new Set(['spam', '1', 'true'])
const HAM_LABELS = new Set(['ham', 'legitimate', 'not spam', 'notspam', '0', 'false'])

function normalizeLabel(raw) {
  const v = String(raw || '').trim().toLowerCase()
  if (SPAM_LABELS.has(v)) return 'spam'
  if (HAM_LABELS.has(v)) return 'ham'
  return null
}

/** Loads and parses the spam email dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/spam_emails.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Please load the email dataset first. (status ${response.status})`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: false,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const fields = parsed.meta.fields || []
  if (!fields.includes('label') || !fields.includes('message')) {
    throw new Error('Dataset is missing required columns: label, message.')
  }

  const seen = new Set()
  const rows = []
  parsed.data.forEach((row) => {
    const label = normalizeLabel(row.label)
    const message = typeof row.message === 'string' ? row.message.trim() : ''
    if (!label || !message) return // drop missing labels / empty messages

    if (seen.has(message)) return // drop duplicate messages
    seen.add(message)

    rows.push({ label, message })
  })

  if (rows.length < 100) {
    throw new Error('Dataset has too few valid email records to train a reliable model.')
  }

  return rows
}

export function computeSummary(emails) {
  const spam = emails.filter((e) => e.label === 'spam')
  const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

  return {
    totalEmails: emails.length,
    spamCount: spam.length,
    legitimateCount: emails.length - spam.length,
    spamPercentage: (spam.length / emails.length) * 100,
    averageLength: avg(emails.map((e) => e.message.length)),
  }
}
