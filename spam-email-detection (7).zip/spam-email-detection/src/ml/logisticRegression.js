function sigmoid(z) {
  return 1 / (1 + Math.exp(-z))
}

/**
 * Logistic regression trained by plain (full-batch) gradient descent
 * directly on the dense TF-IDF vectors, with L2 regularization. Written
 * from scratch rather than via TensorFlow.js — at this vocabulary size a
 * few dozen gradient-descent passes run in well under a second in the
 * browser, so pulling in the full TF.js bundle isn't worth the weight.
 */
export function trainLogisticRegression(trainVectors, trainLabels, vocabSize, {
  epochs = 150, learningRate = 0.6, l2 = 0.0008, onEpoch,
} = {}) {
  const n = trainLabels.length
  const y = trainLabels.map((l) => (l === 'spam' ? 1 : 0))
  let weights = new Float64Array(vocabSize)
  let bias = 0

  for (let epoch = 0; epoch < epochs; epoch++) {
    const gradW = new Float64Array(vocabSize)
    let gradB = 0

    for (let i = 0; i < n; i++) {
      const vec = trainVectors[i]
      let z = bias
      for (let j = 0; j < vocabSize; j++) z += weights[j] * vec[j]
      const pred = sigmoid(z)
      const error = pred - y[i]

      for (let j = 0; j < vocabSize; j++) {
        if (vec[j] !== 0) gradW[j] += error * vec[j]
      }
      gradB += error
    }

    for (let j = 0; j < vocabSize; j++) {
      weights[j] -= learningRate * (gradW[j] / n + l2 * weights[j])
    }
    bias -= learningRate * (gradB / n)

    if (onEpoch) onEpoch(epoch + 1, epochs)
  }

  const predictFromVector = (vector) => {
    let z = bias
    for (let j = 0; j < vocabSize; j++) z += weights[j] * vector[j]
    const spamProbability = sigmoid(z)
    return { spamProbability, predictedLabel: spamProbability >= 0.5 ? 'spam' : 'ham' }
  }

  const topWeights = Array.from(weights)
    .map((w, i) => ({ index: i, weight: w }))
    .sort((a, b) => Math.abs(b.weight) - Math.abs(a.weight))
    .slice(0, 30)

  return {
    type: 'logistic-regression',
    label: 'Logistic Regression',
    weights,
    bias,
    topWeights,
    predictFromVector,
  }
}
