const CLASSES = ['ham', 'spam']
const ALPHA = 0.5 // Laplace smoothing

/**
 * Multinomial Naive Bayes over TF-IDF-weighted features (a standard,
 * widely-used simplification — the weighted values are treated as
 * pseudo-counts in the multinomial scoring formula).
 */
export function trainNaiveBayes(trainVectors, trainLabels, vocabSize) {
  const classCounts = { ham: 0, spam: 0 }
  const featureSums = { ham: new Float64Array(vocabSize), spam: new Float64Array(vocabSize) }
  const totalFeatureSum = { ham: 0, spam: 0 }

  trainLabels.forEach((label, i) => {
    classCounts[label] += 1
    const vec = trainVectors[i]
    let rowSum = 0
    for (let j = 0; j < vocabSize; j++) {
      featureSums[label][j] += vec[j]
      rowSum += vec[j]
    }
    totalFeatureSum[label] += rowSum
  })

  const n = trainLabels.length
  const logPrior = {
    ham: Math.log(classCounts.ham / n),
    spam: Math.log(classCounts.spam / n),
  }

  const logLikelihood = {}
  CLASSES.forEach((cls) => {
    logLikelihood[cls] = new Float64Array(vocabSize)
    const denom = totalFeatureSum[cls] + ALPHA * vocabSize
    for (let j = 0; j < vocabSize; j++) {
      logLikelihood[cls][j] = Math.log((featureSums[cls][j] + ALPHA) / denom)
    }
  })

  const scoreVector = (vector) => {
    const scores = {}
    CLASSES.forEach((cls) => {
      let score = logPrior[cls]
      for (let j = 0; j < vocabSize; j++) {
        if (vector[j] !== 0) score += vector[j] * logLikelihood[cls][j]
      }
      scores[cls] = score
    })
    return scores
  }

  const predictFromVector = (vector) => {
    const scores = scoreVector(vector)
    // softmax over the two class scores for a proper probability
    const maxScore = Math.max(scores.ham, scores.spam)
    const expHam = Math.exp(scores.ham - maxScore)
    const expSpam = Math.exp(scores.spam - maxScore)
    const spamProbability = expSpam / (expHam + expSpam)
    return {
      spamProbability,
      predictedLabel: spamProbability >= 0.5 ? 'spam' : 'ham',
    }
  }

  return {
    type: 'naive-bayes',
    label: 'Naive Bayes',
    logPrior,
    logLikelihood,
    predictFromVector,
  }
}
