const HTML_TAG_REGEX = /<[^>]*>/g
const URL_REGEX = /(https?:\/\/|www\.)[^\s]+/gi
const NON_WORD_REGEX = /[^a-z0-9\s]/g
const WHITESPACE_REGEX = /\s+/g

/**
 * Cleans raw email text for modeling: strips HTML tags and URLs, lowercases,
 * removes punctuation, and normalizes whitespace. Deliberately light-touch —
 * no stopword removal — so meaningful spam-indicative words are never
 * blindly discarded.
 */
export function cleanText(rawText) {
  return (rawText || '')
    .replace(HTML_TAG_REGEX, ' ')
    .replace(URL_REGEX, ' ')
    .toLowerCase()
    .replace(NON_WORD_REGEX, ' ')
    .replace(WHITESPACE_REGEX, ' ')
    .trim()
}

/** Tokenizes cleaned text into words of at least 2 characters. */
export function tokenize(cleanedText) {
  if (!cleanedText) return []
  return cleanedText.split(' ').filter((w) => w.length >= 2)
}

export function cleanAndTokenize(rawText) {
  return tokenize(cleanText(rawText))
}

/** Shuffles and splits emails into 80% train / 20% test, deterministically. */
export function trainTestSplit(items, testRatio = 0.2, seed = 42) {
  const shuffled = seededShuffle(items, seed)
  const testSize = Math.max(1, Math.round(shuffled.length * testRatio))
  const testSet = shuffled.slice(0, testSize)
  const trainSet = shuffled.slice(testSize)
  return { trainSet, testSet }
}

export function seededShuffle(array, seed) {
  const result = [...array]
  let s = seed
  const random = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}
