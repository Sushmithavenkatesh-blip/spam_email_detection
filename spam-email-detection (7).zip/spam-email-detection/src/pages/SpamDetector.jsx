import React, { useRef, useState } from 'react'
import EmailInput from '../components/EmailInput'
import PredictionResult from '../components/PredictionResult'
import ReportButton from '../components/ReportButton'
import { analyzeText } from '../utils/textAnalysis'
import { vectorizeMessage } from '../ml/modelTraining'
import { modelTopTerms } from '../utils/vocabulary'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights, generateModelInsight } from '../utils/insights'

export default function SpamDetector({ engineeredEmails, trainingResult, modelKey, onModelChange, status }) {
  const [result, setResult] = useState(null)
  const [formError, setFormError] = useState(null)
  const resultRef = useRef(null)

  const ready = status === 'ready' && trainingResult

  const handleSubmit = (rawText) => {
    if (!ready) return
    if (!rawText || !rawText.trim()) {
      setFormError('Please enter an email message.')
      setResult(null)
      return
    }
    setFormError(null)

    const model = trainingResult.models[modelKey]
    const { tokens, vector } = vectorizeMessage(rawText, trainingResult.vocabModel)
    const prediction = model.predictFromVector(vector)
    const textStats = analyzeText(rawText)

    const { spamTerms, hamTerms } = modelTopTerms(model, trainingResult.vocabModel, 25)
    const relevantTerms = new Set([...spamTerms, ...hamTerms].map((t) => t.term))
    const matchedTerms = [...new Set(tokens)].filter((t) => relevantTerms.has(t)).slice(0, 10)

    setResult({
      ...prediction,
      modelLabel: model.label,
      textStats,
      matchedTerms,
    })
  }

  const summary = computeSummary(engineeredEmails)
  const insights = [...generateDatasetInsights(engineeredEmails, summary, trainingResult?.vocabModel)]
  const modelInsight = trainingResult ? generateModelInsight(trainingResult.models) : null
  if (modelInsight) insights.push(modelInsight)

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <EmailInput modelKey={modelKey} onModelChange={onModelChange} onSubmit={handleSubmit} disabled={!ready} error={formError} />
        <PredictionResult result={result} innerRef={resultRef} />
      </div>

      {result && (
        <div className="flex justify-end">
          <ReportButton
            summary={summary}
            trainingResult={trainingResult}
            modelKey={modelKey}
            prediction={result}
            insights={insights}
            chartElement={resultRef.current}
          />
        </div>
      )}
    </div>
  )
}
