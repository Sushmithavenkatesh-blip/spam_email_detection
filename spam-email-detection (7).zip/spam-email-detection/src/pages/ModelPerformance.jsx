import React, { useMemo, useRef } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import StatCard from '../components/StatCard'
import ModelMetrics from '../components/ModelMetrics'
import ConfusionMatrix from '../components/ConfusionMatrix'
import VocabularyChart from '../components/VocabularyChart'
import { modelTopTerms } from '../utils/vocabulary'

export default function ModelPerformance({ trainingResult, modelKey, onModelChange }) {
  const spamChartRef = useRef(null)

  if (!trainingResult) {
    return (
      <div className="bg-white rounded-lg border border-black/5 p-8 text-center text-ink/50">
        Training model, results will appear here shortly.
      </div>
    )
  }

  const model = trainingResult.models[modelKey]
  const models = Object.entries(trainingResult.models)
  const { vocabModel } = trainingResult

  const { spamTerms, hamTerms } = useMemo(() => modelTopTerms(model, vocabModel, 10), [model, vocabModel])

  const { tp, tn, fp, fn } = model.metrics.confusionMatrix
  const actualVsPredicted = [
    { category: 'Spam', Actual: tp + fn, Predicted: tp + fp },
    { category: 'Legitimate', Actual: tn + fp, Predicted: tn + fn },
  ]

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-black/5 p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <p className="text-sm text-ink/70 font-medium">Model shown below</p>
        <select
          value={modelKey}
          onChange={(e) => onModelChange(e.target.value)}
          className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="naive-bayes">Naive Bayes</option>
          <option value="logistic-regression">Logistic Regression</option>
        </select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Training Samples" value={trainingResult.trainingSamples} />
        <StatCard label="Testing Samples" value={trainingResult.testingSamples} />
        <StatCard label="Vocabulary Size" value={vocabModel.vocabulary.length} sublabel={`max ${vocabModel.maxVocab}, ${vocabModel.rareTermsRemoved} rare removed`} />
        <StatCard label="ROC-AUC" value={model.metrics.rocAuc !== null ? model.metrics.rocAuc.toFixed(3) : 'N/A'} />
      </div>

      <ModelMetrics metrics={model.metrics} label={model.label} />

      <div className="grid md:grid-cols-2 gap-5">
        <ConfusionMatrix matrix={model.metrics.confusionMatrix} />

        <div ref={spamChartRef} className="bg-white rounded-lg border border-black/5 p-5">
          <h3 className="text-sm font-medium text-ink mb-1">Predicted vs Actual Classes</h3>
          <p className="text-xs text-ink/40 mb-4">Test-set counts, {model.label}</p>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={actualVsPredicted} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
                <CartesianGrid stroke="#e9eaec" vertical={false} />
                <XAxis dataKey="category" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Actual" fill="#1B2130" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Predicted" fill="#4A5FB0" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <VocabularyChart
          terms={spamTerms.map((t) => ({ term: t.term, score: Number(t.score.toFixed(2)) }))}
          dataKey="score"
          title="Spam-Associated Terms"
          description="Top TF-IDF-weighted terms pushing toward Spam — model association, not causation"
          color="#B8543F"
        />
        <VocabularyChart
          terms={hamTerms.map((t) => ({ term: t.term, score: Number(Math.abs(t.score).toFixed(2)) }))}
          dataKey="score"
          title="Legitimate-Associated Terms"
          description="Top TF-IDF-weighted terms pushing toward Legitimate"
          color="#2C7C7A"
        />
      </div>

      <div className="bg-white rounded-lg border border-black/5 p-5">
        <h3 className="text-sm font-medium text-ink mb-4">Model Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[560px]">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
                <th className="py-2 pr-4">Metric</th>
                {models.map(([key, m]) => <th key={key} className="py-2 pr-4">{m.label}</th>)}
              </tr>
            </thead>
            <tbody>
              {['accuracy', 'precision', 'recall', 'f1'].map((metricKey) => (
                <tr key={metricKey} className="border-b border-black/5 last:border-0">
                  <td className="py-2 pr-4 capitalize">{metricKey === 'f1' ? 'F1 Score' : metricKey}</td>
                  {models.map(([key, m]) => (
                    <td key={key} className="py-2 pr-4">{(m.metrics[metricKey] * 100).toFixed(1)}%</td>
                  ))}
                </tr>
              ))}
              <tr>
                <td className="py-2 pr-4">ROC-AUC</td>
                {models.map(([key, m]) => (
                  <td key={key} className="py-2 pr-4">{m.metrics.rocAuc !== null ? m.metrics.rocAuc.toFixed(3) : 'N/A'}</td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
